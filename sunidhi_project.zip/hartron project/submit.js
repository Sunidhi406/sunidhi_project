function handleSubmit() {
    alert("Info submitted successfully! You can receive a call in some time!");
}
