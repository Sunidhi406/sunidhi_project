function getmoreInfo(){
    const info= "Additionally, I Have also done Advanced Diploma in Computer Applications.";
    document.getElementById("info").textContent =  info;
}

